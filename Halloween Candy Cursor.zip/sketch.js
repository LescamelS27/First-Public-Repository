//Note: this is the halloween theme, as the colors are black and white for the spooky season and the cursor of the mouse is designed to be a piece of hard candy

var num = 60;
var x = [];
var y = [];

function setup()  {
  createCanvas(400, 400);
  noStroke();
  
  for (var i = 0; i < num; i++) {
    x[i] = 0;
    print(x.length);
    y[i] = 0;
    print(y.length);
  }
}

function draw() {
  background(0);
  
  for (var i = num-1; i > 0; i--) {
  x[i] = x[i-1];
  y[i] = y[i-1];
  }
  x[0] = mouseX;
  y[0] = mouseY;
  for (var i = 0; i < num; i++) {
    fill(i * 4);
    //make shape of curser image look like a piece of hard candy
    ellipse(x[i], y[i], 40, 40);
    arc(x[i], y[i], 50, 50, 0, HALF_PI);
    arc(x[i], y[i], 50, 50, PI, PI + HALF_PI);
noFill();
    print("candyshape");
  }
}