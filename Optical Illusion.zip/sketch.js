let a;

function setup() {
  createCanvas(400, 400);
  frameRate (30);
  a = 0 / 2;
}

function draw() {
  background(0);
  
  //looped background
  for (var y = 0; y <= height; y += 40){
    for (var x = 0; x <= width; x += 40){
      fill (255, 255);
      ellipse(x, y, 40, 40);
    }
  }
   stroke (150);
  
  //if mouse is pressed on left then focus on black
  //if mouse is pressed on right then focus on white
  if (mouseIsPressed) {
    if (mouseButton == LEFT) {
      stroke (0);
    }
    else if (mouseButton == RIGHT) {
      stroke (255);
    }
  }
  
  //if key is held down play animation of growing circle
  if (keyIsPressed) {
    ellipse(200, 200, a, a);
  a = a + 0.5;
  if (a > 0) {
  }
  }
}