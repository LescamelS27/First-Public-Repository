let img;

function preload() {
  img = loadImage('giraffe.jpg');
  img2 = loadImage('othergiraffe.jpg');
  img3 = loadImage('giraffegiphy.gif');
  img4 = loadImage('squidgiphy.gif');
}

function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  
   background('black');
  fill('yellow');
  textFont('Courier New');
  textSize(17);
  
  text('You see a wild giraffe.', 10, 20);
  text('Do you approach it?',10, 40, 400, 400);
  
   image(img, 90, 90, mouseX, mouseY);
  
  image(img2, 9, mouseY, 70, 70);
  
  image(img3, 240, 40, 40, 40);

  image(img4, 280, 40, 40, 40);
}


